#ifndef LASER_METER_H_
#define LASER_METER_H_

#include <ros/ros.h>
//#include <ros/console.h>
#include <sensor_msgs/Range.h>
#include <std_msgs/Float64.h>

#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include <boost/thread/mutex.hpp>

#include <boost/filesystem.hpp>
#include <boost/thread.hpp>
#include <boost/asio.hpp>

#include "srv_drivers/OpenLaser.h"
#include "srv_drivers/CloseLaser.h"
#include "srv_drivers/ReadLaser.h"
#include "srv_drivers/LaserConditions.h"


using namespace::boost::asio;
using namespace boost::posix_time;
using namespace std;

namespace srv_drivers {

	class LaserMeter {

		public:

			LaserMeter(const ros::NodeHandle nh);
			virtual ~LaserMeter();
			void configure();

		private:

			ros::NodeHandle nodeHandle;

			//Params
			std::string pPort;
			double min_range, max_range;
			std::string frame_id;
			bool receive_inches;


			//Variables
			boost::asio::serial_port *port; // The serial port this instance is connected to


			// Subscribers and publishers
			//ros::Publisher range_publ_;
			ros::ServiceServer serviceOpen, serviceClose, serviceRead, serviceConditions;

			//Timers

			// Frames

			//Mutex
			bool open_laser(srv_drivers::OpenLaser::Request &req, srv_drivers::OpenLaser::Response &res);
			bool close_laser(srv_drivers::CloseLaser::Request &req, srv_drivers::CloseLaser::Response &res);
			bool read_laser(srv_drivers::ReadLaser::Request &req, srv_drivers::ReadLaser::Response &res);
			bool laser_conditions(srv_drivers::LaserConditions::Request &req, srv_drivers::LaserConditions::Response &res);
			bool connect(const std::string& portst);
	};

}

#endif /* LASER_METER_H_*/
