#include "laser_meter.h"

namespace srv_drivers {

	LaserMeter::LaserMeter(const ros::NodeHandle nh):
			nodeHandle(nh)
	{

	}

	LaserMeter::~LaserMeter() {
	}

	void LaserMeter::configure(){

		//Parameters

        nodeHandle.param("min_range", min_range, 0.3);
        ROS_INFO("Min_range: %2.2f", min_range);

        nodeHandle.param("max_range", max_range, 10.0);
        ROS_INFO("Max_range: %2.2f", max_range);

		nodeHandle.param<std::string>("frame_id", frame_id, "laser_meter");
        ROS_INFO("Frame_id: %s", frame_id.c_str());

        nodeHandle.param<std::string>("port", pPort, "/dev/ttyUSB1");
        ROS_INFO("Using port: %s", pPort.c_str());


		//Variables

		// Advertising Topics
		serviceOpen = nodeHandle.advertiseService("open_laser", &LaserMeter::open_laser, this);
		serviceClose = nodeHandle.advertiseService("close_laser", &LaserMeter::close_laser, this);
		serviceRead = nodeHandle.advertiseService("read_laser", &LaserMeter::read_laser, this);
		serviceConditions = nodeHandle.advertiseService("laser_conditions", &LaserMeter::laser_conditions, this);

		// Subscribing Topics

		//Timers

		connect(pPort);
		

	}

	bool LaserMeter::connect(const std::string& portst){

		io_service io;
		const char *PORT = portst.c_str();
		serial_port_base::baud_rate baud_option(19200);
		
		// how big is each "packet" of data (default is 8 bits)
		serial_port_base::character_size char_size( 8 );
		// what flow control is used (default is none)
		serial_port_base::flow_control flow_ctrl( serial_port_base::flow_control::none );
		// what parity is used (default is none)
		serial_port_base::parity parity( serial_port_base::parity::none );
		// how many stop bits are used (default is one)
		serial_port_base::stop_bits stop( serial_port_base::stop_bits::one );	

		try{

			port = new serial_port(io);
			port->open(PORT);
			port->set_option(baud_option); // set the baud rate
			port->set_option(char_size);
			port->set_option(flow_ctrl);
			port->set_option(parity);
			port->set_option(stop);
			cout << "(Laser meter) port " << PORT << " opened\n";

		}catch (boost::system::system_error &e){

			boost::system::error_code ec = e.code();
			cerr << "(laser meter) cannot open port " << PORT << " - error code: " << ec.category().name() << std::endl;
			return false;

		}catch(std::exception e){

			cerr << "(lasermeter) cannot open port " << PORT << " - error code: " << e.what() << endl;
			return false;

		}

		return true;
	}
	// Method to communicate with the serial port to open the laser
	bool LaserMeter::open_laser(srv_drivers::OpenLaser::Request &req, srv_drivers::OpenLaser::Response &res)
	{
		unsigned char laser_command='O';
		unsigned char bu[1];
		boost::asio::write(*(port), boost::asio::buffer(&laser_command, 1)); // write the command "O" to the serial port
		printf (" \n LASER ON\n");
		
		while((bu[0]) != '\n'){
			boost::asio::read(*(port), boost::asio::buffer(bu, 1)); // read the response from the serial port
			printf ("%c" , bu[0]);
		}
	  	return true;
	}
	// Method to communicate with the serial port to close the laser
	bool LaserMeter::close_laser(srv_drivers::CloseLaser::Request &req, srv_drivers::CloseLaser::Response &res)
	{
		unsigned char laser_command='C';
		unsigned char bu[1];

		boost::asio::write(*(port), boost::asio::buffer(&laser_command, 1));// write the command "C" to the serial port
		printf (" \n LASER OFF\n");

		while((bu[0]) != '\n'){
			boost::asio::read(*(port), boost::asio::buffer(bu, 1)); // read the response from the serial port
			printf ("%c" , bu[0]);
		}
		return true;
	}
	// Method to communicate with the serial port to take the distance measure of the laser module
	bool LaserMeter::read_laser(srv_drivers::ReadLaser::Request &req, srv_drivers::ReadLaser::Response &res)
	{
		unsigned char laser_command='D';
		unsigned char bu[1];
		unsigned char buffer[6];
		int bufferCnt = 0;

		boost::asio::write(*(port), boost::asio::buffer(&laser_command, 1));// write the command "D" to the serial port
		printf (" \n LASER READ\n");

		while((bu[0]) != '\n'){
			boost::asio::read(*(port), boost::asio::buffer(bu, 1)); // read the response from the serial port and make the conversion

			if (bu[0] == ':'){
				bufferCnt = 0;

				while(bu[0] != 'm'){
					boost::asio::read(*(port), boost::asio::buffer(bu, 1));
					buffer[bufferCnt] = bu[0];
					bufferCnt++;
				}

				if (buffer[0] == ' '){
					buffer[0] = '0';
				}
				res.dist  = ((int)buffer[0]-48)*10+((int)buffer[1]-48)+((int)buffer[3]-48)*0.1+((int)buffer[4]-48)*0.01+((int)buffer[5]-48)*0.001;
			}
		}
		return true;
	}
	// Method to communicate with the serial port to show the laser module state.
	bool LaserMeter::laser_conditions(srv_drivers::LaserConditions::Request &req, srv_drivers::LaserConditions::Response &res)
	{
		unsigned char laser_command='S';
		unsigned char bu[1];

		boost::asio::write(*(port), boost::asio::buffer(&laser_command, 1));// write the command "S" to the serial port
		printf (" \n LASER CONDITIONS\n");

		while((bu[0]) != '\n'){
			boost::asio::read(*(port), boost::asio::buffer(bu, 1)); // read the response from the serial port
			printf ("%c" , bu[0]);
		}
		return true;
	}
}
