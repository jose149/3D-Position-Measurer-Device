#include "laser_meter.h"

int main(int argc, char** argv) {

	ros::init (argc, argv, "laser_meter_node");
  	ros::NodeHandle n("~");
  	
	srv_drivers::LaserMeter lm(n);
	lm.configure();
	ros::spin();
	return 0;
}
