#!/usr/bin/env python
# license removed for brevity
#######################################################################################################
#######################################################################################################
#
#   THIS PROGAM LAUNCH A ROS NODE WHICH MANAGES A LASER METER BY MEANS OF A TOWER THAT IS CONTROLLED BY GAMEPAD
#  
#   * LIBRARIES
#   * CLASS
#        * INITIALIZATIONS
#        * INTERRUPTIONS CALLBACK
#        * LASER SERVICES
#        * PROGRAM
#          * INITIALIZATION
#          * PRIMMARY PROGRAM
#             * MOVEMENT
#             * PRIMMARY BUTTONS
#             * SECUNDARY BUTTONS
#          * ROBUSTNESS PROGRAM
#        * FUNCTIONS
#   * MAIN PROGRAMM
#          
#######################################################################################################
#######################################################################################################

#######################################################################################################
# LIBRARIES
#######################################################################################################
import rospy
import time
import math
import statistics
from statistics import stdev 
from std_msgs.msg import String
from std_msgs.msg import Float64
from sensor_msgs.msg import Joy
from srv_drivers.srv import *

#######################################################################################################
# CLASS
#######################################################################################################
class TowerController(object):

    def __init__(self, buttons, axes, factor_fast_pan, factor_fast_tilt, factor_slow_pan, factor_slow_tilt, servo_step, P_pan_ini, P_tilt_ini, P_pan, P_tilt, button_pressed, P_pan_servo, P_tilt_servo):

     #######################################################################################################
     # INITIALIZATION
     #######################################################################################################
        self.buttons = buttons   # Buttons gamepad
        self.axes = axes         # Axes gamepad
        self.factor_fast_pan = factor_fast_pan  # Speed gamepad
        self.factor_fast_tilt = factor_fast_tilt
        self.factor_slow_pan = factor_slow_pan
        self.factor_slow_tilt = factor_slow_tilt
        self.servo_step = servo_step
        self.P_pan_ini = P_pan_ini  # Slow gamepad
        self.P_tilt_ini = P_tilt_ini
        self.P_pan = P_pan
        self.P_tilt = P_tilt
        self.button_pressed = button_pressed
        self.P_pan_servo = P_pan_servo
        self.P_tilt_servo = P_tilt_servo

    # Callback of the gamepad
    def callback(self, joy_msg):
       self.buttons = joy_msg.buttons
       self.axes = joy_msg.axes

    def pan_callback(self, pan):
        self.P_pan_servo = pan.data * 180.0/math.pi

    def tilt_callback(self, tilt):
        self.P_tilt_servo = tilt.data * 180.0/math.pi

 # gamepad node interruption
    def joy_listener(self):
        rospy.Subscriber('/gamepad', Joy, self.callback)
        
    def arbotix_listener(self):
    	rospy.Subscriber('/arm_shoulder_pan_joint/command',Float64, self.pan_callback)
        rospy.Subscriber('/arm_shoulder_tilt_joint/command',Float64, self.tilt_callback)

 #######################################################################################################
 # LASER SERVICES
 #######################################################################################################
 # Open laser service
    def open_laser(self):
        rospy.wait_for_service('/open_laser')

        try:
            opn_laser = rospy.ServiceProxy('/open_laser', OpenLaser)
            opn_laser()
        except rospy.ServiceException, e:
            print "Service call failed: %s"%e

 # Close laser service
    def close_laser(self):
        rospy.wait_for_service('/close_laser')

        try:
          cls_laser = rospy.ServiceProxy('/close_laser', CloseLaser)
          cls_laser()
        except rospy.ServiceException, e:
          print "Service call failed: %s"%e

    # Read laser distance service
    def read_laser(self):
        rospy.wait_for_service('/read_laser')

        try:
            rd_laser = rospy.ServiceProxy('/read_laser', ReadLaser)
            laser_distance = rd_laser()
            return laser_distance.dist
        except rospy.ServiceException, e:
            print "Service call failed: %s"%e

 # show the laser state information service
    def laser_conditions(self):
        rospy.wait_for_service('/laser_conditions')

        try:
            cond_laser = rospy.ServiceProxy('/laser_conditions', LaserConditions)
            cond_laser()
        except rospy.ServiceException, e:
            print "Service call failed: %s"%e

    #######################################################################################################
    # INITIALIZATION
    #######################################################################################################

    # Shows manual and move the servos to the calibration process start position
    def setup(self):
        self.setGamepadManual()
        self.movePanToPos(self.P_pan_ini)
        self.moveTiltToPos(self.P_tilt_ini)

    #######################################################################################################
    # PRIMMARY PROGRAM
    #######################################################################################################

    def loop(self):
        global closed_laser
        global id_anchor
        global anchors_list
        global num_anchors_assigned
        global num_ball


        if self.button_pressed == False:

      #######################################################################################################
      # MOVEMENT
      #######################################################################################################
      
            # Allows arrows to move the device slowly
            if self.axes[4] != 0 and self.axes[5] == 0:
                if self.buttons[6] == 1: # activate secundary functions
                    self.button_pressed = True
                pan_angle_added  =  self.axes[4]  * self.servo_step 
                tilt_angle_added = -self.axes[5]  * self.servo_step
                self.P_pan  = self.P_pan  + pan_angle_added
                self.P_tilt = self.P_tilt + tilt_angle_added

            elif self.axes[5] != 0 and self.axes[4] == 0:
                if self.buttons[6] == 1: # activate secundary functions
                    self.button_pressed = True
                pan_angle_added  =  self.axes[4] * self.factor_slow_pan  * self.servo_step 
                tilt_angle_added = -self.axes[5] * self.factor_slow_tilt * self.servo_step 
                self.P_pan  = self.P_pan  + pan_angle_added
                self.P_tilt = self.P_tilt + tilt_angle_added

            # Left joystick to move fastly 
            elif (self.axes[0] != 0 or self.axes[1] != 0):
                pan_angle_added  =  self.axes[0] * self.factor_fast_pan  * self.servo_step 
                tilt_angle_added = -self.axes[1] * self.factor_fast_tilt * self.servo_step 
                self.P_pan  = self.P_pan  + pan_angle_added
                self.P_tilt = self.P_tilt + tilt_angle_added

            # PTU position limitations
            if self.P_pan    < 0.000:
                self.P_pan  = 0.000

            elif self.P_pan  > 299.739:
                self.P_pan  = 299.739

            elif self.P_tilt < -50:
                self.P_tilt  = -50 

            elif self.P_tilt > 50.000:
                self.P_tilt  = 50.000
            self.movePanToPos(self.P_pan)
            self.moveTiltToPos(self.P_tilt)

            #######################################################################################################
            # PRIMARY BUTTONS
            #######################################################################################################

            # Button Triangle to save the position or to write a text file
            if self.buttons[0] == 1:
                self.button_pressed = True
                # Write a text file with the anchors position information
                if self.buttons[6] == 1: # activate secundary functions
                    if (num_anchors_assigned > 0):
                        self.writting_text(anchors_list, num_anchors_assigned)
                        self.write_text_distance_A2L(anchors_list, num_anchors_assigned)
                    # Give a warning that no anchors has been asigned
                    else:
                        if(num_anchors_assigned == -1):
                            print("Please, take minimum one anchor measure and its reference")
                        else:
                            print("Please, take minimum one anchor measure")
                    archivo = open("postions servos.txt","w")
                    archivo.write("sample,"+ "distance," + "X," + "Y," + "Z," + "PAN," + "TILT," +"\n")
                # Take measure and save it to the database
                else:
                    closed_laser = True
                    measure = self.take_measure()
                    # Save a new anchor in the database if the ID is not registered
                    if (id_anchor == num_anchors_assigned) and (num_anchors_assigned < max_num_anchors):
                        id_anchor = id_anchor +1
                        num_anchors_assigned = num_anchors_assigned +1
                        anchors_list = self.add_anchors_list(anchors_list, id_anchor, measure)     
                    # Change the anchor information of the new measure
                    elif(id_anchor > 0):
                        self.change_anchors_list(anchors_list, id_anchor, measure, num_anchors_assigned)
                    self.print_anchors_position(anchors_list, 0, num_anchors_assigned)

            # Button circle to open and close the laser
            elif self.buttons[1] == 1:
                self.button_pressed = True
                if closed_laser == True:
                    closed_laser = False
                    self.open_laser()
                else:
                    closed_laser = True
                    self.close_laser()

            # Button cross to read laser distance
            elif self.buttons[2] == 1:
                self.button_pressed = True
                # Activate the assessment method to make it easier and faster
                if (self.buttons[6] == 1): # activate secundary functions
                    if (id_anchor == 0):
                        closed_laser = True
                        average = [0,0,0]
                        sampleX = []
                        sampleY = []
                        sampleZ = []
                        # Take "max_num_anchors" measures for each marker
                        for i in range (0, (max_num_anchors)):
                            measure = self.take_measure()
                            id_anchor = id_anchor +1
                            num_anchors_assigned = num_anchors_assigned +1
                            anchors_list = self.add_anchors_list(anchors_list, id_anchor, measure)
                            time.sleep(2)
                        # Write a .txt file with the samples data
                        archivo = open("Sample_n %d" %num_ball + ".txt","w")
                        archivo.write("sample,"+ "distance," + "X," + "Y," + "Z," + "PAN," + "TILT," +"\n")
                        for i in range (0,max_num_anchors+1):
                            text = "%d"%anchors_list[i*7] + ","
                            for a in range (1,7):
                                text = text + "%.5f" %anchors_list[(i*7+a)] + ","
                            archivo.write(text + "\n")
                            if (i>0):
                                sampleX.append(anchors_list[(i*7+2)])
                                sampleY.append(anchors_list[(i*7+3)])
                                sampleZ.append(anchors_list[(i*7+4)])
                                average[0] = average[0] + anchors_list[(i*7+2)]
                                average[1] = average[1] + anchors_list[(i*7+3)]
                                average[2] = average[2] + anchors_list[(i*7+4)]
                        archivo.close()
                        # Write a sample results .txt file
                        print ("Results text file is written")
                        self.write_samples_result(average, max_num_anchors, sampleX, sampleY, sampleZ, num_ball)
                        num_ball = num_ball +1
                        id_anchor = 0
                        num_anchors_assigned = 0
                        for i in range(0,(7*max_num_anchors)):
                            anchors_list.pop() 
                    else:
                        print ("Need to take the samples reference before")
                # Take measure without saving it into the database
                else:
                    closed_laser = True
                    measure = self.take_measure()
                    anchors_list = self.add_anchors_list(anchors_list, id_anchor, measure)
                    self.print_anchors_position(anchors_list, num_anchors_assigned+1 , num_anchors_assigned+1)
                    for i in range (0,7):
                        anchors_list.pop()

            # Button square to delete the last database position
            elif self.buttons[3] == 1 and num_anchors_assigned >= 0:
                self.button_pressed = True
                for i in range (0,7):
                    anchors_list.pop()
                if id_anchor == num_anchors_assigned:
                    id_anchor = id_anchor -1
                num_anchors_assigned = num_anchors_assigned -1
                self.print_anchors_position(anchors_list, 0, num_anchors_assigned)

            #######################################################################################################
            # SECUNDARY BUTTONS
            #######################################################################################################

            # Button START to show the gamepad manual
            elif self.buttons[9] == 1:
                self.button_pressed = True
                self.setGamepadManual()

            # Button SELECT to show the position of the servos
            elif self.buttons[8] == 1:
                self.button_pressed = True
                P_servo = " \n THE SERVO'S PAN POSITION IS %.2f \n"% self.P_pan_servo
                P_servo = P_servo + "THE SERVO'S TILT POSITION IS %.2f "% self.P_tilt_servo
                print(P_servo)
                self.laser_conditions()
                if (num_anchors_assigned>=0):
                    self.print_anchors_position(anchors_list, 0 , num_anchors_assigned)
                else:
                    print("NO ANCHORS AND REFERENCE DETECTED \n")
                print(num_anchors_assigned)

            # Button R2 to move the servos to their start position
            elif self.buttons[7] == 1:
            	self.button_pressed = True
            	# Move to the Hardware calibration position
            	if self.buttons[6] == 1: # activate secundary functions
            		self.P_pan  = 149.21
            	# Move to the calibration season initial position
                else:
                    self.P_pan  = P_pan_ini
                self.P_tilt = P_tilt_ini
                self.movePanToPos(self.P_pan)
                self.moveTiltToPos(self.P_tilt)


            # Button L1 to go to the next anchor
            elif self.buttons[4] == 1: 
                self.button_pressed = True
                # Give a warning that no anchors has been asigned
                if num_anchors_assigned <= 0:
                    print ("NO ANCHOR ASSIGNED, INVALID PROCESS")
                else:
                    if id_anchor == num_anchors_assigned:
                        id_anchor = 0
                    else:
                        id_anchor = id_anchor +1
                    self.P_pan  = anchors_list[id_anchor*7 +5]
                    self.P_tilt = anchors_list[id_anchor*7 +6]
                    self.movePanToPos(self.P_pan)
                    self.moveTiltToPos(self.P_tilt)            

            # Button R1 to go to the next anchor
            elif self.buttons[5] == 1:
                self.button_pressed = True
                # Give a warning that no anchors has been asigned
                if num_anchors_assigned <= 0:
                    print ("NO ANCHOR ASSIGNED, INVALID PROCESS")
                else:
                    if id_anchor == 0:
                        id_anchor = num_anchors_assigned
                    else:
                        id_anchor = id_anchor -1

                    self.P_pan  = anchors_list[id_anchor*7 +5]
                    self.P_tilt = anchors_list[id_anchor*7 +6]
                    self.movePanToPos(self.P_pan)
                    self.moveTiltToPos(self.P_tilt)

       #######################################################################################################
       # PROTECTION PROGRAM
       #######################################################################################################

        # Allows to press the same or another button again
        else:
            buttons_sum = 0
            axes_sum = 0

            for i in range (0,12):
                buttons_sum = buttons_sum + self.buttons[i]

            for i in range (0,6):
                if self.axes[i] != 0:
                    axes_sum = 1

            if (buttons_sum == 0) or (self.buttons[6] == 1 and axes_sum == 0 and buttons_sum == 1):
                self.button_pressed = False
        if (self.P_pan < self.P_pan_servo + 0.1 and self.P_pan > self.P_pan_servo - 0.1 and self.P_tilt < self.P_tilt_servo + 0.1 and self.P_tilt > self.P_tilt_servo - 0.1):
        	self.P_pan  = self.P_pan_servo
        	self.P_tilt = self.P_tilt_servo
        self.setparams()

     #######################################################################################################
     # FUNCTIONS
     #######################################################################################################
    # Shows the gamepad manual on the screen
    def setGamepadManual(self):
        print("\n\n")
        localtime = time.asctime( time.localtime(time.time()) )
        print("     Date " + localtime)
        print("\n                   GAMEPAD INFORMATION\n")
        print("           MOVEMENT: \n")
        print("           LEFT JOYSTICK: MOVE FASTER")
        print("           L2 + ARROWS:   MOVE STEP BY STEP")
        print("           ARROWS:        MOVE SLOWER")
        print("\n           PRIMARY BUTTONS: \n")
        print("           TRIANGLE:      SAVE ANCHOR POSITION")
        print("           CIRCLE:        ON/OFF LASER")
        print("           CROSS:         TAKE MEASURE")
        print("           SQUARE:        DELETE LAST ANCHOR POSITION")
        print("\n           SECUNDARY BUTTONS:\n")  
        print("           START:         GAMEPAD INFORMATION")
        print("           SELEC:         STATUS")
        print("           R2:            MOVE TO CALIBRATION SEASON INITIAL POSITION")
        print("           R1:            MOVE TO THE POSITION OF THE PREVIOUS ANCHOR")
        print("           L1:            MOVE TO THE POSITION OF THE NEXT ANCHOR")
        print("\n           COMBINATION BUTTONS: \n")
        print("           L2 + TRIANGLE: WRITE IN A txt FILE THE ANCHORS POSITION")
        print("           L2 + R2:  	 MOVE TO THE HARDWARE CALIBRATION POSITION")
    # Move the pan servo position
    def movePanToPos(self, pose):    
        pub_pan.publish(pose *math.pi/180) 
    # Move the tilt servo position
    def moveTiltToPos(self, pose):
        pub_tilt.publish(pose*math.pi/180) 
    # set the parameters
    def setparams(self):
        self.factor_fast_pan  = rospy.get_param('~factor_fast_pan')
        self.factor_fast_tilt = rospy.get_param('~factor_fast_tilt')
        self.factor_slow_pan  = rospy.get_param('~factor_slow_pan')
        self.factor_slow_tilt = rospy.get_param('~factor_slow_tilt')
        self.servo_step = rospy.get_param('~servo_step')
        self.frequency  = rospy.get_param('~frequency')
        self.P_pan_ini  = rospy.get_param('~P_pan_ini')
        self.P_tilt_ini = rospy.get_param('~P_tilt_ini')
        max_num_anchors = rospy.get_param('~max_num_anchors')

    # perform the calculations to get the measure in 3D
    def take_measure(self):
        distance = self.read_laser() - 0.006 # this last term is the calibration calculation, did it with another laser meter.
        # Distance between the laser module to the upper servo position
        Lx = 0.003
        Ly = 0.000
        Lz = 0.043
        # Trigonometric operations using Pan & Tilt angle
        CP = math.cos((self.P_pan_servo-149.21)*math.pi/180)
        SP = math.sin((self.P_pan_servo-149.21)*math.pi/180)
        CT = math.cos(self.P_tilt_servo*math.pi/180)
        ST = math.sin(self.P_tilt_servo*math.pi/180)
        # Results
        X = distance*CP*CT + Lx*CP*CT - Ly*SP + Lz*CP*ST
        Y = distance*SP*CT + Lx*SP*CT + Ly*CP + Lz*SP*ST
        Z = -distance*ST - Lx*ST + Lz*CT        
        measure=[distance, X , Y, Z]
        return measure
        
    # Add the new position to the database
    def add_anchors_list(self, anchors_list, id_anchor, measure):
        if id_anchor > 0:
            measure[1] = measure[1] - anchors_list [2]
            measure[2] = measure[2] - anchors_list [3]
            measure[3] = measure[3] - anchors_list [4]
        anchors_list.append(id_anchor)
        anchors_list.append(measure[0])
        anchors_list.append(measure[1])
        anchors_list.append(measure[2])
        anchors_list.append(measure[3])
        anchors_list.append(self.P_pan_servo)
        anchors_list.append(self.P_tilt_servo)
        return anchors_list
    # Change a previously asigned position to the database
    def change_anchors_list(self, anchors_list, id_anchor, measure, num_anchors_assigned):
        if id_anchor == 0:
            for i in range(1,num_anchors_assigned + 1):
                anchors_list[i*7 + 2] = anchors_list[i*7 + 2] + anchors_list[2] - measure[1]
                anchors_list[i*7 + 3] = anchors_list[i*7 + 3] + anchors_list[3] - measure[2]
                anchors_list[i*7 + 4] = anchors_list[i*7 + 4] + anchors_list[4] - measure[3] 
        anchors_list[id_anchor*7 + 1] = measure[0]
        anchors_list[id_anchor*7 + 2] = measure[1] - anchors_list [2]
        anchors_list[id_anchor*7 + 3] = measure[2] - anchors_list [3]
        anchors_list[id_anchor*7 + 4] = measure[3] - anchors_list [4]
        anchors_list[id_anchor*7 + 5] = self.P_pan_servo
        anchors_list[id_anchor*7 + 6] = self.P_tilt_servo
        return anchors_list
    # Shows the database on the screen
    def print_anchors_position(self, anchors_list, initvalue, num_anchors_assigned):
        text = ""
        for i in range (initvalue,num_anchors_assigned +1):
            text = text + "  ID= %d"    %anchors_list[i*7]
            text = text + "  D = %.5f"  %anchors_list[(i*7+1)] + "m"
            text = text + "  X= %.5f"   %anchors_list[(i*7+2)] + "m"
            text = text + "  Y= %.5f"   %anchors_list[(i*7+3)] + "m"
            text = text + "  Z= %.5f"   %anchors_list[(i*7+4)] + "m"
            text = text + "  PAN= %.2f" %anchors_list[(i*7+5)] + "o"
            text = text + "  TILT= %.2f"%anchors_list[(i*7+6)] + "o"
            text= text + "\n"
        print (text)
    #write the database on a .txt file
    def writting_text(self, anchors_list, num_anchors_assigned):
        print("escribo el fichero Position of the anchors (from reference).txt")
        archivo = open("Position of the anchors (from reference).txt","w")
        archivo.write("anchor ID,"+ "distance," + "X," + "Y," + "Z," + "PAN," + "TILT," +"\n")
        for i in range (0,num_anchors_assigned +1):
            text = "%d" %anchors_list[i*7] + ","
            for a in range (1,7):
            	text = text + "%.5f," %anchors_list[(i*7+a)]
            archivo.write(text + "\n")
        archivo.close()  
    #write the measures of the database without reference (the "world" position) comparation on a .txt file
    def write_text_distance_A2L(self, anchors_list, num_anchors_assigned):
        print("escribo el fichero Position of the anchors (without reference).txt")
        archivo = open("Position of the anchors (without reference).txt" ,"w")
        archivo.write("anchor ID,"+ "distance," + "X," + "Y," + "Z," + "PAN," + "TILT," +"\n")
        for i in range (0,num_anchors_assigned +1):
            text = "%d" %anchors_list[i*7] + ","
            text = text + "%.5f" %anchors_list[(i*7+1)] + ","
            if (i==0):
                text = text + "%.5f" %anchors_list[(i*7+2)] + ","
                text = text + "%.5f" %anchors_list[(i*7+3)] + ","
                text = text + "%.5f" %anchors_list[(i*7+4)] + ","
            else:       
                text = text + "%.5f" %(anchors_list[(i*7+2)] + anchors_list[2]) + ","
                text = text + "%.5f" %(anchors_list[(i*7+3)] + anchors_list[3]) + ","
                text = text + "%.5f" %(anchors_list[(i*7+4)] + anchors_list[4]) + ","
            text = text + "%.2f" %anchors_list[(i*7+5)] + ","
            text = text + "%.2f" %anchors_list[(i*7+6)]
            archivo.write(text + "\n")
        archivo.close() 
    #write the assessment results on a .txt file
    def write_samples_result(self, average, max_num_anchors, sampleX, sampleY, sampleZ, num_ball):
        archivo = open("Results_n %d" %num_ball + ".txt","w")
        archivo.write("num ball,"+ "sigma X," + "sigma Y," + "sigma Z," + "averageX," + "averageY," + "averageZ," +"\n")
        average[0] = average[0]/max_num_anchors
        average[1] = average[1]/max_num_anchors
        average[2] = average[2]/max_num_anchors

        text = "%d" % num_ball
        text = text + ",%s" % (statistics.stdev(sampleX))
        text = text + ",%s" % (statistics.stdev(sampleY))
        text = text + ",%s" % (statistics.stdev(sampleZ))
        text = text + ",%.5f" %average[0]
        text = text + ",%.5f" %average[1]
        text = text + ",%.5f" %average[2]
        archivo.write(text)
        archivo.close()
 

if __name__ == '__main__':

    rospy.init_node('System_Controller', anonymous=True)

    # Reading parameters
    factor_fast_pan = rospy.get_param('~factor_fast_pan')
    factor_fast_tilt = rospy.get_param('~factor_fast_tilt')
    factor_slow_pan = rospy.get_param('~factor_slow_pan')
    factor_slow_tilt = rospy.get_param('~factor_slow_tilt')
    servo_step = rospy.get_param('~servo_step')
    frequency = rospy.get_param('~frequency')
    P_pan_ini = rospy.get_param('~P_pan_ini')
    P_tilt_ini = rospy.get_param('~P_tilt_ini')
    max_num_anchors = rospy.get_param('~max_num_anchors')

    #default values
    P_pan = P_pan_ini
    P_tilt = P_tilt_ini
    P_pan_servo = P_pan_ini
    P_tilt_servo = P_tilt_ini
    buttons = [0,0,0,0,0,0,0,0,0,0,0,0,0]
    axes = [0,0,0,0,0,0,0]
    button_pressed = False 
    closed_laser = True
    id_anchor = -1
    anchors_list = []
    num_anchors_assigned = -1
    num_ball = 1

    # Creating publishers
    pub_pan = rospy.Publisher('/arm_shoulder_pan_joint/command', Float64, queue_size=10)
    pub_tilt = rospy.Publisher('/arm_shoulder_tilt_joint/command', Float64, queue_size=10) 

    rate = rospy.Rate(frequency) # 10hz

    # Starting to communicate with PTU
    tc = TowerController(buttons, axes, factor_fast_pan, factor_fast_tilt, factor_slow_pan, factor_slow_tilt, servo_step, P_pan_ini, P_tilt_ini, P_pan, P_tilt, button_pressed, P_pan_servo, P_tilt_servo)
    time.sleep(5)
    tc.setup()
    # Interruptions
    try:
        tc.joy_listener() 
        tc.arbotix_listener()
    except rospy.ROSInterruptException:
        pass

    while not rospy.is_shutdown():
        tc.loop()
        rate.sleep()
        